﻿using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EBookController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public EBookController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult Get()
        {
            string query = @"select Id, BookName, Description, Publisher, Date, ISBN, Quantity, Price, Issued from dbo.EBook";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult(table);
        }


        [HttpPost]
        public JsonResult Post(EBook book)
        {
            string query = @"
                    insert into dbo.EBook values 
                    ('" + book.Id + @"', '" + book.BookName + @"'
, '" + book.Description + @"' 
, '" + book.Publisher + @"'
, '" + book.Date + @"'
, '" + book.ISBN + @"'
, '" + book.Quantity + @"'
, '" + book.Price + @"'
, '" + book.Issued + @"' )";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Added Successfully");
        }


        [HttpPut]
        public JsonResult Put(EBook book)
        {
            string query = @"
                    update dbo.EBook set    
                    Name = '" + book.BookName + @"',                   
                    Name = '" + book.Description + @"'
                    Name = '" + book.Publisher + @"'
                    Name = '" + book.Date + @"' 
                    Name = '" + book.ISBN + @"'
                    Name = '" + book.Quantity + @"'
                    Name = '" + book.Price + @"'
                    Name = '" + book.Issued + @"'
                    where Id = " + book.Id + @" 
                    ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Updated Successfully");
        }


        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
                    delete from dbo.EBook
                    where Id = " + id + @" 
                    ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Deleted Successfully");


        }
    }
}
