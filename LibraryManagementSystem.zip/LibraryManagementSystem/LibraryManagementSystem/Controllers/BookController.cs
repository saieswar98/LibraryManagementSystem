﻿using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public BookController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult Get()
        {
            string query = @"select Id, BookName, ISBN, Description, Publisher,Auhtor,Price, Issue, Category, Quantity  from dbo.Book";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult(table);
        }


        [HttpPost]
        public JsonResult Post(Book book)
        {
            string query = @"
                    insert into dbo.Book values 
                    ('" + book.Id + @"', '" + book.BookName + @"', '" + book.ISBN + @"'
, '" + book.Description + @"' , '" + book.Publisher + @"','" + book.Auhtor + @"',  '" + book.Price + @"'
, '" + book.Issue + @"' , '" + book.Category + @"','" + book.Quantity + @"' )";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Added Successfully");
        }


        [HttpPut]
        public JsonResult Put(Book book)
        {
            string query = @"
                    update dbo.Book set 
                    Name = '" + book.BookName + @"',
                    Name = '" + book.ISBN + @"'
                    Name = '" + book.Description + @"'
                    Name = '" + book.Publisher + @"'
                    Name = '" + book.Auhtor + @"'
                    Name = '" + book.Price + @"'
                    Name = '" + book.Issue + @"'
                    Name = '" + book.Category + @"'
                   Name = '" + book.Quantity + @"'
                    where Id = " + book.Id + @" 
                    ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Updated Successfully");
        }


        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
                    delete from dbo.Book
                    where Id = " + id + @" 
                    ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Deleted Successfully");


        }
    }
}
