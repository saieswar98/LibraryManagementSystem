﻿using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookIssueController
    {
        private readonly IConfiguration _configuration;

        public BookIssueController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult Get()
        {
            string query = @"select UserId,BookId, BookName, Author,  Date, ReturnDate from dbo.Issue";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult(table);
        }


        [HttpPost]
        public JsonResult Post(BookIssue book)
        {
            string query = @"
                    insert into dbo.Issue values 
                    ('" + book.UserId + @"', '" + book.BookId + @"', '" + book.BookName + @"'
, '" + book.Author + @"' , '" + book.Date + @"', '" + book.ReturnDate + @"')";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Added Successfully");
        }


        [HttpPut]
        public JsonResult Put(BookIssue book)
        {
            string query = @"
                    update dbo.Issue set 
                    UserId = '" + book.UserId + @"',
                    BookId = '" + book.BookId + @"'
                    Name = '" + book.BookName + @"'
                    Auther = '" + book.Author + @"'
                    Date = '" + book.Date + @"'
                    ReturnDate = '" + book.ReturnDate + @"'
                    
                    ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Updated Successfully");
        }


        [HttpDelete("{Userid}")]
        public JsonResult Delete(int id)
        {
            string query = @"
                    delete from dbo.Issue
                    where UserId = " + id + @" 
                    ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("libraryAppCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader); ;

                    myReader.Close();
                    myCon.Close();
                }
            }

            return new JsonResult("Deleted Successfully");


        }
    }
}
